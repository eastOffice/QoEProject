// start test:
var getOder = require('./random')
module.exports = {
    'POST /start': async (ctx, next) => {
        var fs = require('fs');
        var mturkID = ctx.request.body.MTurkID;
        var device = ctx.request.body.device;
        var age = ctx.request.body.age;
        console.log(mturkID, device, age);
        var filename = "./results/" + mturkID + ".txt";
        console.log(filename);
        fs.writeFile(filename, mturkID + "\n" + device + "\n" + age + '\n', function(err) {
            if(err) {
                return console.log(err);
            }
            console.log("Initial Write Success!");
        });

        var video_order = getOder(1,13);

        ctx.render('1.html', {
            title: '1/13', filename:filename, video_order = video_order
        });
    }
};
